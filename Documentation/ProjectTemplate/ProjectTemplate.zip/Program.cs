﻿using IfKThenX;
using IfKThenX.Interfaces;

IConnectionParametes connection = new ConnectionParameters("192.0.2.1"); // Set IP of your bus interface.
IBusManager bus = new BusManager(connection);
await bus.ConnectAsync();

IBusState kBusState = new BusState();
kBusState.AddOrUpdateState(new State()
{
    Address = "1/1/63",
    Value = new byte[1] { 1 },
    DataPointType = DataPointType.Dpt1
});

IBusState xBusState = new BusState();
xBusState.AddOrUpdateState(new State()
{
    Address = "1/1/71",
    Value = new byte[1] { 1 },
    DataPointType = DataPointType.Dpt1
});

IX x = new X(xBusState);
IK k = new K(kBusState, x);
bus.AddCondition(k);

Console.ReadKey();          // Keep the app running.